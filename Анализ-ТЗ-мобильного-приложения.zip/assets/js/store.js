(function () {
  'use strict';
  var NS = 'ptk_v1_';
  var user = null;

  function load(key, fallback) {
    try {
      var v = localStorage.getItem(NS + key);
      return v === null ? fallback : JSON.parse(v);
    } catch (e) { return fallback; }
  }
  function save(key, val) {
    try { localStorage.setItem(NS + key, JSON.stringify(val)); } catch (e) {}
  }

  var seed = {
    profile: {
      id: 1, full_name: 'Александр Петров', email: 'alex.petrov@mail.ru', phone: '+7 (912) 345-67-89',
      level: 15, rating: 2340, age: 34, gender: 'male', goal: 'Похудение',
      interests: ['Бег', 'Футбол'], streak: 12, trainings: 38, avatarHue: 0,
      role: 'client', community: 'Клуб бега «Петровские»', is_minor: false, sportsman_id: 'PT-4821-9037'
    },
    achievements: [
      { id: 1, title: 'Первая тренировка', desc: 'Проведи первую тренировку по плану', icon: 'run', progress: 100, achieved: true, achieved_at: '01.06.2026' },
      { id: 2, title: 'Марафонец', desc: 'Пробеги 10 км за один забег', icon: 'trophy', progress: 75, achieved: false },
      { id: 3, title: 'Ранняя пташка', desc: '5 тренировок до 8 утра', icon: 'sun', progress: 100, achieved: true, achieved_at: '18.06.2026' },
      { id: 4, title: 'Сила воли', desc: 'Выполняй план 4 недели подряд', icon: 'flame', progress: 60, achieved: false },
      { id: 5, title: 'Друг сообщества', desc: 'Добавь 3 друзей в приложение', icon: 'users', progress: 100, achieved: true, achieved_at: '25.06.2026' },
      { id: 6, title: 'Челленджер', desc: 'Заверши челлендж «10 000 шагов»', icon: 'medal', progress: 40, achieved: false }
    ],
    friends: [
      { id: 11, full_name: 'Анна Смирнова', rating: 980, is_online: true },
      { id: 12, full_name: 'Дмитрий Козлов', rating: 1140, is_online: false },
      { id: 13, full_name: 'Ольга Морозова', rating: 640, is_online: true },
      { id: 14, full_name: 'Сергей Никитин', rating: 875, is_online: false }
    ],
    friendRequests: [
      { id: 21, full_name: 'Екатерина Лебедева', rating: 902, is_online: true },
      { id: 22, full_name: 'Андрей Волков', rating: 720, is_online: false }
    ],
    gto: {
      step: 'золото',
      standards: [
        { id: 1, name: 'Бег 100 м', target: '13,3 сек', current: '14,2 сек', progress: 40, status: 'in_progress' },
        { id: 2, name: 'Подтягивания', target: '9 раз', current: '9 раз', progress: 100, status: 'achieved' },
        { id: 3, name: 'Отжимания', target: '24 раза', current: '12 раз', progress: 30, status: 'in_progress' },
        { id: 4, name: 'Наклон вперёд', target: '8 см', current: null, progress: 0, status: 'not_started' }
      ],
      history: {
        1: [15.1, 14.9, 14.6, 14.5, 14.2],
        3: [8, 10, 11, 12]
      }
    },
    plan: {
      goal: 'weight_loss', goalLabel: 'Похудение', level: 'beginner', levelLabel: 'Начинающий',
      preferences: ['Бег', 'Растяжка'],
      days: [
        { day: 'Пн', label: 'Понедельник', kind: 'Бег', items: [{ name: 'Бег 30 мин', dur: '30 мин', detail: 'Темп спокойный, пульс 130–150 уд/мин' }], status: 'done' },
        { day: 'Ср', label: 'Среда', kind: 'Интервалы', items: [{ name: 'Интервальный бег 20 мин', dur: '20 мин', detail: '5×2 мин ускорение, отдых 1 мин' }, { name: 'Растяжка 10 мин', dur: '10 мин', detail: 'Комплекс на все группы мышц' }], status: 'planned' },
        { day: 'Пт', label: 'Пятница', kind: 'Силовая', items: [{ name: 'Приседания 3×15', dur: '15 мин', detail: 'Классические приседания, корпус прямой' }, { name: 'Отжимания 3×10', dur: '10 мин', detail: 'Отдых между подходами 60 сек' }], status: 'planned' }
      ]
    },
    consultations: [
      { id: 1, trainer: 'Иванов Игорь', question: 'Как правильно выполнять приседания?', answer: 'Держите спину прямой, колени не заходят за носки. Начните с 2 подходов по 12 повторений.', status: 'answered', created: '08.07.2026', answered_at: '08.07.2026' },
      { id: 2, trainer: 'Петрова Анна', question: 'Сколько раз в неделю бегать для похудения?', answer: '3 раза в неделю достаточно. Два беговых и одно интервальное.', status: 'answered', created: '15.07.2026', answered_at: '16.07.2026' },
      { id: 3, trainer: 'Иванов Игорь', question: 'Помогите составить режим на беговой неделе', status: 'pending', created: '03.08.2026' }
    ],
    news: [
      {
        id: 1, type: 'news', category: 'Новости', title: 'Победа в турнире!',
        date: '15.06.2026', preview: 'Команда Петровского одержала победу в финале районного турнира по мини-футболу со счётом 3:1.',
        content: 'Команда Петровского одержала победу в финале районного турнира по мини-футболу со счётом 3:1. Голы забили Дмитрий Козлов и дважды Сергей Никитин. Тренер отмечает слаженную игру и отличную физическую форму команды в этом сезоне. Поздравляем всех участников и болельщиков!',
        likes: 24, liked: false, comments: [ {a: 'Ольга М.', t: 'Поздравляем команду! 🔥'}, {a: 'Сергей К.', t: 'Так держать!'} ], cover: 'football'
      },
      {
        id: 2, type: 'event', category: 'Событие', title: 'Марафон «10 000 шагов»',
        date: '02.08.2026', preview: 'Новый челлендж для всего сообщества. Пройдите 10 000 шагов в день в течение недели и получите значок.',
        content: 'Новый челлендж для всего сообщества. Пройдите 10 000 шагов в день в течение недели и получите значок «Челленджер». Участники, прошедшие все 7 дней, разыграют призы среди участников в финале месяца.',
        likes: 41, liked: true, comments: [ {a: 'Анна С.', t: 'Участвую!'}, {a: 'Дмитрий К.', t: 'Отличная мотивация'}, {a: 'Екатерина Л.', t: 'Пойдёмте вместе на стадион' } ], cover: 'steps'
      },
      {
        id: 3, type: 'news', category: 'Новости', title: 'Новые тренажёры в спортзале',
        date: '28.07.2026', preview: 'В основном зале установлены кардиотренажёры нового поколения. Запись на тренировку — через бронирование в приложении.',
        content: 'В основном зале установлены кардиотренажёры нового поколения: беговые дорожки с датчиками пульса и эллиптические тренажёры. Запись на тренировку — через бронирование в приложении. Просьба ознакомиться с инструкцией по технике безопасности.',
        likes: 18, liked: false, comments: [ {a: 'Игорь В.', t: 'Наконец-то!'} ], cover: 'gym'
      },
      {
        id: 4, type: 'event', category: 'Событие', title: 'Открытие бегового сезона',
        date: '10.07.2026', preview: 'Традиционный осенний кросс в парке усадьбы. Дистанции 3 и 10 км, участие свободное для всех жителей.',
        content: 'Традиционный кросс в парке усадьбы. Дистанции 3 и 10 км, участие свободное для всех жителей поселения. Регистрация в разделе «Соревнования», старт в 10:00. Предусмотрен детский забег на 500 метров.',
        likes: 9, liked: false, comments: [], cover: 'run'
      }
    ],
    events: [
      {
        id: 1, title: 'Летний Кубок по мини-футболу', dates: '15.06 — 20.06.2026', status: 'ongoing',
        registered: true, participants: '24 из 32', location: 'Стадион спорткомплекса',
        desc: 'Любительский турнир среди команд поселения. Олимпийская система, победитель получает Кубок и 500 баллов.',
        rating: [ {place: 1, name: 'ФК «Петровские»', score: 18, is_user: false}, {place: 2, name: 'Команда Козлова', score: 15, is_user: false}, {place: 3, name: 'Звезда', score: 12, is_user: false} ],
        rounds: [ ['ФК «Петровские»', 'Звезда'], ['Команда Козлова', 'Быстрые'] ], roundLabel: 'Полуфиналы'
      },
      {
        id: 2, title: 'Марафон «10 000 шагов»', dates: '03.08 — 09.08.2026', status: 'ongoing',
        registered: false, participants: '87 участников', location: 'Весь посёлок',
        desc: 'Недельный челлендж по шагам. Каждый день — 10 000 шагов, за всю неделю — значок «Челленджер» и 300 баллов.',
        rating: [ {place: 1, name: 'Анна Смирнова', score: 100, is_user: false}, {place: 2, name: 'Иван Петров', score: 91, is_user: true} ]
      },
      {
        id: 3, title: 'Турнир по настольному теннису', dates: '24.08.2026', status: 'upcoming',
        registered: false, participants: '12 из 32', location: 'Зал настольного тенниса',
        desc: 'Одиночный турнир, круговая система до 21 очка. Разыгрывается три комплекта наград.',
        rating: []
      },
      {
        id: 4, title: 'Кросс памяти', dates: '12.05.2026', status: 'completed',
        registered: true, participants: '142 участника', location: 'Парк усадьбы',
        desc: 'Традиционный весенний кросс на 3 и 10 км.',
        rating: [ {place: 1, name: 'Дмитрий Козлов', score: 10, is_user: false}, {place: 2, name: 'Иван Петров', score: 9, is_user: true} ]
      }
    ],
    dialogs: [
      { id: 'coach', name: 'Иванов Игорь', role: 'Тренер', type: 'personal', online: true, unread: 0, last: 'Держи темп! Следи за пульсом.', time: '14:32' },
      { id: 'club', name: 'Клуб бега «Петровские»', role: '24 участника', type: 'group', online: true, unread: 3, last: 'Ольга: Готовимся к кроссу в субботу', time: '11:05' },
      { id: 'anna', name: 'Анна Смирнова', role: '', type: 'personal', online: true, unread: 0, last: 'Я записалась на бассейн!', time: 'вчера' },
      { id: 'dm', name: 'Дмитрий Козлов', role: '', type: 'personal', online: false, unread: 1, last: 'Скинь расписание тренировок', time: 'пн' }
    ],
    messages: {
      coach: [
        { who: 'them', t: 'Привет! Как прошла сегодняшняя тренировка?', time: '14:10' },
        { who: 'me', t: 'Нормально, бег 30 минут, пульс держал 140', time: '14:18' },
        { who: 'them', t: 'Отлично. В среду делаем интервалы — 5×2 минуты ускорения.', time: '14:25' },
        { who: 'them', t: 'Держи темп! Следи за пульсом.', time: '14:32' }
      ],
      club: [
        { who: 'them', t: 'Анна: Все на субботний кросс в парк! Сбор в 9:00', time: '10:40' },
        { who: 'them', t: 'Ольга: Готовимся к кроссу в субботу', time: '11:05' }
      ],
      anna: [
        { who: 'them', t: 'Привет! Ты видел новый марафон по шагам?', time: '12:01' },
        { who: 'me', t: 'Да, уже участвую 😄', time: '12:20' },
        { who: 'them', t: 'Я записалась на бассейн!', time: '12:33' }
      ],
      dm: [
        { who: 'them', t: 'Скинь расписание тренировок', time: '09:15' }
      ]
    },
    bookings: [
      { id: 1, facility: 'Бассейн', date: '16.07.2026', time: '19:00 — 20:00', status: 'completed' },
      { id: 2, facility: 'Спортзал №1', date: '02.08.2026', time: '18:00 — 19:00', status: 'confirmed' }
    ],
    attendance: {
      monthVisits: 8,
      heat: [0,0,1,2,0,1,0, 0,1,0,2,0,1,1, 2,0,1,0,3,0,2, 1,0,2,0,3,0,1, 0,0,0],
      stats: [ {m: 'Фев', v: 4}, {m: 'Мар', v: 6}, {m: 'Апр', v: 5}, {m: 'Май', v: 7}, {m: 'Июн', v: 9}, {m: 'Июл', v: 8} ]
    },
    notifications: [
      { id: 1, type: 'training_start', title: 'Тренировка начнётся через 30 минут', text: 'Интервальный бег 20 мин · 19:00, Спорткомплекс', time: '18:30', date: 'Сегодня', read: false },
      { id: 2, type: 'booking', title: 'Вы записаны на групповую тренировку', text: 'Бассейн, четверг 19:00 — 20:00 · тренер Петрова Анна', time: '11:20', date: 'Сегодня', read: false },
      { id: 3, type: 'cancel', title: 'Тренировка отменена', text: 'Теннисный корт · Смирнов Павел · 18:00. Перенесена на пятницу.', time: '09:05', date: 'Вчера', read: true },
      { id: 4, type: 'event', title: 'Открыта регистрация на Кросс памяти', text: 'Большое событие поселения · 12.05, парк усадьбы. Регистрация в разделе «Соревнования».', time: '12:41', date: 'Пн', read: false },
      { id: 5, type: 'gto', title: 'Норматив ГТО: обновление результата', text: 'Бег 100 м — новый результат 14,2 сек. До знака «золото» остался один норматив.', time: 'вчера', date: 'Пн', read: true }
    ],
    communities: [
      {
        id: 'run', name: 'Клуб бега «Петровские»', category: 'Бег', members: 128,
        friends: ['Анна Смирнова', 'Дмитрий Козлов'], joined: true, cover: 'run',
        desc: 'Регулярные пробежки по парку усадьбы, подготовка к кроссам и марафонам. Сборы каждое воскресенье в 9:00 у входа в парк.',
        events: [
          { id: 101, title: 'Кросс памяти', dates: '12.05.2026', time: '10:00', place: 'Парк усадьбы' },
          { id: 102, title: 'Воскресная пробежка 10 км', dates: 'каждое вс', time: '09:00', place: 'Стадион' }
        ],
        schedule: [
          { day: 'Вт', time: '19:00', title: 'Групповая: интервалы', coach: 'Иванов Игорь' },
          { day: 'Чт', time: '19:00', title: 'Групповая: ОФП', coach: 'Иванов Игорь' },
          { day: 'Вс', time: '09:00', title: 'Длинная пробежка', coach: 'Самостоятельно' }
        ]
      },
      {
        id: 'football', name: 'ФК «Петровские»', category: 'Футбол', members: 96,
        friends: ['Сергей Никитин'], joined: false, cover: 'football',
        desc: 'Любительская команда поселения, тренировки дважды в неделю, участие в районном первенстве.',
        events: [
          { id: 103, title: 'Летний Кубок', dates: '15.06 — 20.06.2026', time: 'по расписанию', place: 'Стадион спорткомплекса' }
        ],
        schedule: [
          { day: 'Пн', time: '20:00', title: 'Командная тренировка', coach: 'Смирнов Павел' },
          { day: 'Чт', time: '20:00', title: 'Игровая практика', coach: 'Смирнов Павел' }
        ]
      },
      {
        id: 'swim', name: 'Клуб «Акватика»', category: 'Плавание', members: 74,
        friends: ['Анна Смирнова'], joined: false, cover: 'steps',
        desc: 'Плавание для взрослых и детей, подготовка к нормам ГТО по плаванию и участие в заплывах.',
        events: [
          { id: 104, title: 'Открытый заплыв', dates: '28.06.2026', time: '11:00', place: 'Бассейн' }
        ],
        schedule: [
          { day: 'Ср', time: '19:30', title: 'Групповая: техника кроля', coach: 'Петрова Анна' },
          { day: 'Сб', time: '10:00', title: 'Групповая: свободное плавание', coach: 'Петрова Анна' }
        ]
      },
      {
        id: 'tennis', name: 'Теннисный клуб', category: 'Теннис', members: 52,
        friends: [], joined: false, cover: 'gym',
        desc: 'Любительский теннис и настольный теннис, аренда корта для участников клуба со скидкой 20%.',
        events: [
          { id: 105, title: 'Турнир по настольному теннису', dates: '24.08.2026', time: '12:00', place: 'Зал настольного тенниса' }
        ],
        schedule: [
          { day: 'Вт', time: '18:00', title: 'Групповая: для начинающих', coach: 'Смирнов Павел' },
          { day: 'Пт', time: '19:00', title: 'Спарринг-сессии', coach: 'Самостоятельно' }
        ]
      }
    ],
    ratingBreakdown: [
      { id: 1, reason: 'Участие в марафоне «10 000 шагов»', points: 100, date: '05.08.2026', cat: 'event' },
      { id: 2, reason: 'Тренировка по плану (Бег 30 мин)', points: 25, date: '02.08.2026', cat: 'train' },
      { id: 3, reason: 'Посещение спорткомплекса по QR-карточке', points: 10, date: '01.08.2026', cat: 'visit' },
      { id: 4, reason: 'Друзья: приглашена Анна Смирнова', points: 20, date: '20.07.2026', cat: 'social' },
      { id: 5, reason: 'Достижение «Ранняя пташка»', points: 50, date: '18.06.2026', cat: 'achieve' },
      { id: 6, reason: 'Прогресс ГТО: бег 100 м', points: 30, date: '27.07.2026', cat: 'gto' },
      { id: 7, reason: 'Приглашена Ольга Морозова на баскетбол', points: 20, date: '12.07.2026', cat: 'social' }
    ],
    ratingStats: { regionPlace: 3, regionTotal: 812, friendsPlace: 2, friendsTotal: 5, trend: [120, 150, 210, 260, 320, 380, 450], weekDelta: 47 },
    myWorkouts: [],
    exerciseLibrary: [
      { id: 1, name: 'Бег на месте', group: 'Кардио', dur: '1 мин' },
      { id: 2, name: 'Приседания', group: 'Ноги', dur: '3×15' },
      { id: 3, name: 'Отжимания', group: 'Грудь', dur: '3×10' },
      { id: 4, name: 'Планка', group: 'Кор', dur: '30 сек' },
      { id: 5, name: 'Выпады', group: 'Ноги', dur: '3×12' },
      { id: 6, name: 'Подтягивания', group: 'Спина', dur: '3×8' },
      { id: 7, name: 'Бёрпи', group: 'Кардио', dur: '3×10' },
      { id: 8, name: 'Наклон вперёд', group: 'Растяжка', dur: '30 сек' }
    ],
    gtoPrep: [
      { id: 1, name: 'Бег 100 м · ускорения', dur: '5×2 мин' },
      { id: 2, name: 'Подтягивания', dur: '4×макс' },
      { id: 3, name: 'Отжимания', dur: '3×20' },
      { id: 4, name: 'Наклон вперёд · растяжка', dur: '2×45 сек' }
    ],
    surveys: [
      { id: 1, when: '02.08.2026', training: 'Бег 30 мин', feeling: 'good', intensity: 'medium', difficulty: 'easy', note: 'Всё отлично, пульс держал в зоне' },
      { id: 2, when: '30.07.2026', training: 'Интервалы', feeling: 'ok', intensity: 'hard', difficulty: 'medium', note: 'Интервалы дались тяжело, но доволен результатом' }
    ]
  };

  var App = window.App = {};

  App.get = function (k, fb) { return load(k, fb === undefined ? null : fb); };
  App.set = function (k, v) { save(k, v); };

  App.award = function (n) {
    var p = App.get('profile', {});
    p.rating = (p.rating || 0) + n;
    App.set('profile', p);
    App.set('points', App.get('points', 0) + n);
    return p.rating;
  };

  App.init = function () {
    if (!load('seeded', false)) { for (var k in seed) { save(k, seed[k]); } save('seeded', true); }
    else { for (var k2 in seed) { if (load(k2, null) === null) save(k2, seed[k2]); } }
    var pr = load('profile', null);
    if (pr && pr.full_name === 'Иван Петров') {
      pr.full_name = seed.profile.full_name; pr.rating = seed.profile.rating; pr.level = seed.profile.level;
      save('profile', pr);
    }
    var rS = load('ratingStats', null);
    if (rS) { rS.regionPlace = seed.ratingStats.regionPlace; rS.weekDelta = seed.ratingStats.weekDelta; save('ratingStats', rS); }
    var app = document.querySelector('.app');
    if (app) app.classList.add('enter');
    var t = new Date();
    var el = document.getElementById('sb-time');
    if (el) el.textContent = String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0');
    var act = document.body.getAttribute('data-active');
    if (act) {
      var items = document.querySelectorAll('.btmnav-item');
      for (var i = 0; i < items.length; i++) {
        if (items[i].getAttribute('data-tab') === act) items[i].classList.add('active');
      }
    }
  };

  App.$ = function (sel, root) { return (root || document).querySelector(sel); };
  App.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  App.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  App.uid = function () { return 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); };

  App.initials = function (name) {
    return String(name || '?').split(/\s+/).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase();
  };
  App.avatarClass = function (name) {
    var n = 0; for (var i = 0; i < name.length; i++) n += name.charCodeAt(i);
    return 'b' + ((n % 4) + 1);
  };
  App.avatar = function (name, size) {
    var cls = App.avatarClass(name);
    var s = size === 'lg' ? 's56' : size === 'sm' ? 's40' : 's48';
    return '<span class="avatar ' + s + ' ' + cls + '">' + App.esc(App.initials(name)) + '</span>';
  };

  App.nav = function (href) { location.href = href; };
  App.back = function () {
    if (window.history.length > 1) { window.history.back(); } else { location.href = 'home.html'; }
  };

  App.toast = function (msg) {
    var app = document.querySelector('.app');
    if (!app) return;
    var t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    app.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 350); }, 2200);
  };

  App.fmtDate = function (iso) {
    var d = new Date(iso);
    return String(d.getDate()).padStart(2, '0') + '.' + String(d.getMonth() + 1).padStart(2, '0') + '.' + d.getFullYear();
  };

  App.qrSVG = function (seedVal) {
    var n = 25, cells = [];
    var x = (seedVal || 7) * 9301 + 49297;
    for (var r = 0; r < n; r++) {
      for (var c = 0; c < n; c++) {
        var finder = (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7);
        var on;
        if (finder) {
          var rr = r < 7 ? r : r - (n - 7), cc = c < 7 ? c : c - (n - 7);
          on = (rr === 0 || rr === 6 || cc === 0 || cc === 6) || (rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4);
        } else {
          x = (x * 9301 + 49297) % 233280;
          on = (x % 100) < 46;
        }
        cells.push(on);
      }
    }
    var size = 21, rects = [];
    for (var i = 0; i < cells.length; i++) {
      if (cells[i]) {
        var r2 = Math.floor(i / n), c2 = i % n;
        rects.push('<rect x="' + (c2 * size) + '" y="' + (r2 * size) + '" width="' + (size - 1) + '" height="' + (size - 1) + '"/>');
      }
    }
    return '<svg viewBox="0 0 ' + (n * size) + ' ' + (n * size) + '" xmlns="http://www.w3.org/2000/svg" style="width:min(62vw,250px);height:auto">' +
      '<rect width="100%" height="100%" fill="#fff"/>' +
      '<g fill="#0d1217">' + rects.join('') + '</g></svg>';
  };

  App.sparkSVG = function (values, id, color) {
    var w = 300, h = 70, pad = 8;
    var max = Math.max.apply(null, values), min = Math.min.apply(null, values);
    var range = (max - min) || 1;
    var pts = values.map(function (v, i) {
      var x = pad + (i / (values.length - 1)) * (w - pad * 2);
      var y = h - pad - ((v - min) / range) * (h - pad * 2);
      return [x.toFixed(1), y.toFixed(1)];
    });
    var line = pts.map(function (p, i) { return (i ? 'L' : 'M') + p[0] + ' ' + p[1]; }).join(' ');
    var area = line + ' L' + (w - pad) + ' ' + (h - pad) + ' L' + pad + ' ' + (h - pad) + ' Z';
    var col = color || 'var(--accent)';
    return '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="none">' +
      '<defs><linearGradient id="g' + id + '" x1="0" y1="0" x2="0" y2="1">' +
      '<stop offset="0" stop-color="' + col + '" stop-opacity="0.25"/><stop offset="1" stop-color="' + col + '" stop-opacity="0"/>' +
      '</linearGradient></defs>' +
      '<path class="area" d="' + area + '" fill="url(#g' + id + ')"/>' +
      '<path class="line" d="' + line + '"/>' +
      '<circle cx="' + pts[pts.length - 1][0] + '" cy="' + pts[pts.length - 1][1] + '" r="3.4"/></svg>';
  };

  App.cover = function (type) {
    var defs = {
      football: ['#00518F', '#0070C9', '👟'],
      steps: ['#0A2E52', '#1B5B9C', '🏃'],
      gym: ['#2C3E50', '#4A6785', '🏋'],
      run: ['#0B3A66', '#2E7CC4', '🏃'],
      pool: ['#0B4F6C', '#1282A2', '🏊']
    };
    var d = defs[type] || defs.football;
    return '<svg class="cover" viewBox="0 0 400 225" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">' +
      '<rect width="400" height="225" fill="' + d[0] + '"/>' +
      '<circle cx="330" cy="40" r="120" fill="' + d[1] + '" opacity="0.5"/>' +
      '<circle cx="70" cy="210" r="150" fill="' + d[1] + '" opacity="0.35"/>' +
      '<circle cx="360" cy="190" r="60" fill="' + d[1] + '" opacity="0.3"/>' +
      '<g stroke="rgba(255,255,255,0.14)" stroke-width="2">' +
      '<line x1="0" y1="112" x2="400" y2="112"/><line x1="200" y1="0" x2="200" y2="225"/>' +
      '<circle cx="200" cy="112" r="52" fill="none"/></g>' +
      '<text x="200" y="138" font-family="Manrope, sans-serif" font-size="72" font-weight="800" text-anchor="middle" fill="rgba(255,255,255,0.95)">' + d[2] + '</text></svg>';
  };

  App.barIcon = function (name) {
    var p = {
      run: '<path d="M2 21h4l10-13 3 2-8 6v8"/><circle cx="16" cy="5" r="2"/><path d="M9 15l3-2 4 4 4 1"/>',
      trophy: '<path d="M7 4h10v4a5 5 0 0 1-10 0V4z"/><path d="M7 6H4v1a4 4 0 0 0 4 4"/><path d="M17 6h3v1a4 4 0 0 1-4 4"/><path d="M12 14v3m0 3h4m-4-3h-4m4 0v3"/>',
      sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
      flame: '<path d="M12 3c1 3-3 4-3 8a3 3 0 0 0 6 0c0-1-.5-2-1-3 3 1 4 3 4 5a6 6 0 1 1-12 0c0-4 3-6 6-10z"/>',
      users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17" cy="9" r="2.6"/><path d="M16 14.5a5 5 0 0 1 5.5 4.6"/>',
      medal: '<circle cx="12" cy="14" r="6"/><path d="M8.5 9.5L7 3l4 3 1-3 4 3-1.5 6.5"/>',
      heart: '<path d="M12 20s-7-4.5-9-9a5 5 0 0 1 9-3 5 5 0 0 1 9 3c-2 4.5-9 9-9 9z"/>',
      chat: '<path d="M4 6h16a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H9l-5 4v-4H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z"/>',
      phone: '<path d="M6 3h12a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M10 19h4"/>',
      star: '<path d="M12 3l2.7 5.6 6.3.8-4.6 4.2 1.2 6.2L12 17l-5.6 2.8 1.2-6.2L3 9.4l6.3-.8L12 3z"/>',
      qr: '<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4z"/><path d="M13 13h2v2h-2zM17 13h4v4h-4zM13 17h2v4h-2zM17 17h4v4h-4zM20 6h1M6 20h1M20 13h1"/>',
      cal: '<path d="M4 6h16v15H4z"/><path d="M4 10h16M8 3v4m8-4v4"/>',
      check: '<path d="M4 12.5l5 5L20 6.5"/>',
      x: '<path d="M6 6l12 12M18 6L6 18"/>',
      arrow: '<path d="M15 5l-7 7 7 7"/>',
      chev: '<path d="M9 6l6 6-6 6"/>',
      pin: '<path d="M12 21s-7-5.5-7-11a7 7 0 0 1 14 0c0 5.5-7 11-7 11z"/><circle cx="12" cy="10" r="2.6"/>',
      clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/>',
      bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6l1-7z"/>',
      download: '<path d="M12 4v11m0 0l-4-4m4 4l4-4M4 20h16"/>',
      share: '<circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="19" r="2.6"/><path d="M8.2 10.8l7.6-4.6m-7.6 7l7.6 4.6"/>',
      send: '<path d="M3 11l18-8-8 18-2.5-7L3 11z"/>',
      paperclip: '<path d="M20 12l-7.5 7.5a5.5 5.5 0 0 1-8-8L13 3.5a3.5 3.5 0 0 1 5 5l-8.5 8.5a1.5 1.5 0 0 1-2-2L15 6"/>',
      mic: '<path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
      camera: '<path d="M4 7h3l2-3h6l2 3h3a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1z"/><circle cx="12" cy="13" r="3.4"/>',
      home: '<path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-5v-6h-4v6H5a1 1 0 0 1-1-1v-9z"/>',
      dumbbell: '<path d="M5 9v6m-2-4v2m4-6h6l4 4-4 4H9M13 15l4 4m0-8l3 3m-3-3l-3 3"/>',
      users2: '<path d="M17 20v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1"/><circle cx="10" cy="7" r="3.4"/><path d="M21 20v-1a4 4 0 0 0-3-3.9M15.5 3.6a3.5 3.5 0 0 1 0 6.8"/>',
      search: '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.5-4.5"/>',
      plus: '<path d="M12 5v14M5 12h14"/>',
      back: '<path d="M15 5l-7 7 7 7"/>',
      badge: '<circle cx="12" cy="9" r="6"/><path d="M9 9l2.2 2.2L15.5 7"/><path d="M9.5 14l-1 6 3.5-2 3.5 2-1-6"/>',
      edit: '<path d="M4 20h4L20 8l-4-4L4 16v4z"/>',
      eye: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z"/><circle cx="12" cy="12" r="2.6"/>',
      refresh: '<path d="M20 11a8 8 0 1 0-1.5 6.5M20 4v7h-7"/>'
    };
    var d = p[name] || p.bolt;
    return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>';
  };

  App.icon = function (name, size) {
    var d = {
      wifi: '<path d="M2.5 9a16 16 0 0 1 19 0M5.5 12.5a11 11 0 0 1 13 0M8.5 16a6 6 0 0 1 7 0"/>',
      signal: '<path d="M5 12v4M10 9v7M15 6v10M20 3v17"/>',
      battery: '<rect x="2" y="8" width="17" height="8" rx="2"/><path d="M21 11v2"/>'
    };
    return '<svg width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' + (d[name] || '') + '</svg>';
  };

  document.addEventListener('DOMContentLoaded', App.init);
})();
